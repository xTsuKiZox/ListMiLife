ChemyRetro...  Groooooooovy-fied!

This is a 60s-70s retro-styled font I did from scratch working with CorelDraw and FontForge.  It is one of my first creations that I'm really proud of, and I wanted to share to the font/art community.
.  
Included in the font are two Basic Latin Characters, Cyrillic, Greek, Vietnamese, Turkish and other foreign accented characters.  There's also Punctuation, Currency, some Symbol and Letter-like characters, I may attempt to update soon with other characters.

I have also included the TrueType font version, for anyone that would like to use it.

I hope that my work on this font would be of value as I have enjoyed making them.  

It is of my own work and it's FREE of charge for ALL uses.  Credits are welcomed but not necessary, however, I like to see what you do with them.

Thank you for your interest in ChemyRetro.

::jaybx73@gmail.com::


Jay Batch
WanderingJazz